#! /usr/bin/env node
import inquirer from "inquirer";
console.log("Quiz Questions");
const answer = await inquirer.prompt({
    name: "select",
    message: "Which Subject you want to perform Quiz",
    type: "list",
    choices: ["HTML", "Typescript", "Python"]
});
//HTML , Typescript, Python
if (answer.select === "HTML") {
    const quiz = await inquirer.prompt([
        {
            name: "Q1",
            type: "list",
            message: "\nQ:1 What does HTML stand for?",
            choices: ["Hyperlinks and Text Markup Language", "Hyper Text Markup Language", "Home Tool Markup Language", ""]
        },
        {
            name: "Q2",
            type: "list",
            message: "\nQ:2 Who is making the Web standards?",
            choices: ["Mozilla", "Microsoft", "The World Wide Web Consortium", "Google"]
        },
        {
            name: "Q3",
            type: "list",
            message: "\nQ:3 Choose the correct HTML element for the largest heading:",
            choices: ["<h1>", "<h6>", "<head>", "<heading>"]
        },
        {
            name: "Q4",
            type: "list",
            message: "\nQ:4 What is the correct HTML element for inserting a line break?",
            choices: ["<lb>", "<br>", "<break>"]
        },
        {
            name: "Q5",
            type: "list",
            message: "\nQ:5 What is the correct HTML for adding a background color?",
            choices: ["<background>yellow</background>", "<body bg='yellow'>", "<body style='background-color:yellow;''>"]
        }
    ]);
    let scores = 0;
    console.log("\n \n");
    console.log("------------Options which you are Select------------");
    switch (quiz.Q1) {
        case "Hyper Text Markup Language":
            console.log(`${quiz.Q1} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q1} - Incorrect Option`);
    }
    switch (quiz.Q2) {
        case "The World Wide Web Consortium":
            console.log(`${quiz.Q2} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q2} - Incorrect Option`);
    }
    switch (quiz.Q3) {
        case "<h1>":
            console.log(`${quiz.Q3} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q3} - Incorrect Option`);
    }
    switch (quiz.Q4) {
        case "<br>":
            console.log(`${quiz.Q4} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q4} - Incorrect Option`);
    }
    switch (quiz.Q5) {
        case "<body style='background-color:yellow;''>":
            console.log(`${quiz.Q5} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q5} - Incorrect Option`);
    }
    console.log("\n------------Your Result------------");
    console.log(`Your Score out of 5 is: ${scores}`);
    //TypeScritp
}
else if (answer.select === "Typescript") {
    const quiz = await inquirer.prompt([
        {
            name: "Q1",
            type: "list",
            message: "\nQ:1 What are the three main 'simple types' in TypeScript?",
            choices: ["Boolean, String, Number", "Array, Object, Number", "Object, Array, Symbol", "Object, Array, Symbol"]
        },
        {
            name: "Q2",
            type: "list",
            message: "\nQ:2 What type of assignment is this variable, `const fullName: string = 'Abubakar Khan';`?",
            choices: ["Explicit", "Implicit"]
        },
        {
            name: "Q3",
            type: "list",
            message: "\nQ:3 True or False: TypeScript can always correctly infer a variables type.",
            choices: ["False", "True"]
        },
        {
            name: "Q4",
            type: "list",
            message: "\nQ:4 ______ is similar to 'any', but a safer alternative when uncertain about the type.",
            choices: ["Never", "Unknown", "Similar"]
        },
        {
            name: "Q5",
            type: "list",
            message: "\nQ:5 Type Aliases are mostly used with ______.",
            choices: ["Booleans", "Strings", "Numbers"]
        }
    ]);
    let scores = 0;
    console.log("\n \n");
    console.log("------------Options which you are Select------------");
    switch (quiz.Q1) {
        case "Boolean, String, Number":
            console.log(`${quiz.Q1} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q1} - Incorrect Option`);
    }
    switch (quiz.Q2) {
        case "Explicit":
            console.log(`${quiz.Q2} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q2} - Incorrect Option`);
    }
    switch (quiz.Q3) {
        case "False":
            console.log(`${quiz.Q3} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q3} - Incorrect Option`);
    }
    switch (quiz.Q4) {
        case "Unknown":
            console.log(`${quiz.Q4} - Correct Option)`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q4} - Incorrect Option`);
    }
    switch (quiz.Q5) {
        case "Strings":
            console.log(`${quiz.Q5} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q5} - Incorrect Option`);
    }
    console.log("\n------------Your Result------------");
    console.log(`Your Score out of 5 is: ${scores}`);
    //Flutter
}
else if (answer.select === "Python") {
    const quiz = await inquirer.prompt([
        {
            name: "Q1",
            type: "list",
            message: "\nQ:1 What is a correct syntax to output 'Hello World' in Python?",
            choices: ["print('Hello World')", "p('Hello World')", "echo('Hello World');", "echo 'Hello World'"]
        },
        {
            name: "Q2",
            type: "list",
            message: "\nQ:2 Which one is NOT a legal variable name?",
            choices: ["my-var", "myvar", "Myvar", "my_var"]
        },
        {
            name: "Q3",
            type: "list",
            message: "\nQ:3 How do you create a variable with the numeric value 5?",
            choices: ["x = int(5)", "Both the other answers are correct", "x = 5"]
        },
        {
            name: "Q4",
            type: "list",
            message: "\nQ:4 What is the correct file extension for Python files?",
            choices: [".py", ".pyth", ".pyt", ".pt"]
        },
        {
            name: "Q5",
            type: "list",
            message: "\nQ:5 What is the correct way to create a function in Python?",
            choices: ["function myfunction():", "create myFunction():", "NOT", "def myFunction():"]
        }
    ]);
    let scores = 0;
    console.log("\n \n");
    console.log("------------Options which you are Select------------");
    switch (quiz.Q1) {
        case "print('Hello World')":
            console.log(`${quiz.Q1} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q1} - Incorrect Option`);
    }
    switch (quiz.Q2) {
        case "my-var":
            console.log(`${quiz.Q2} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q2} - Incorrect Option`);
    }
    switch (quiz.Q3) {
        case "Both the other answers are correct":
            console.log(`${quiz.Q3} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q3} - Incorrect Option`);
    }
    switch (quiz.Q4) {
        case ".py":
            console.log(`${quiz.Q4} - Correct Option)`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q4} - Incorrect Option`);
    }
    switch (quiz.Q5) {
        case "def myFunction():":
            console.log(`${quiz.Q5} - Correct Option`);
            ++scores;
            break;
        default:
            console.log(`${quiz.Q5} - Incorrect Option`);
    }
    console.log("\n------------Your Result------------");
    console.log(`Your Score out of 5 is: ${scores}`);
}
